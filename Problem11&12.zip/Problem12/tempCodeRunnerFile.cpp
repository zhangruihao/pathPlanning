Node> pop = pop_init(1000);  //生成个体数量为100的种群
    // int cnt = 0;
    // for (int i = 0; i < pop.size(); i++)
    //     if (checkHasAllYellow(pop[i].path)) cnt++;
    // cout << "hasAllYellow: " << cnt << endl;
    // GA ga = GA(pop, 1000, 1.0, 1.0, 0.3);
    // // ga.evolve();
    // int generation = 100;  //迭代次数
    // for (int i = 0; i <= generation; i++) {
    //     cout << i << endl;
    //     ga.evolve();
    // }
    // ga.outputResult();
    // puts("end");
    // cout << doubl